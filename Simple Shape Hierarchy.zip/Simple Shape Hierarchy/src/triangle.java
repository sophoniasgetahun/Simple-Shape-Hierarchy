class Triangle extends Shape {
    final double base;
    final double height;

    public Triangle(String color, double base, double height) {
        super(color);
        this.base = base;
        this.height = height;
    }

    public double calculateArea() {
        return 0.5 * base * height;
    }

    public double calculatePerimeter() {
        // For simplicity, let's assume it's an equilateral triangle
        return 3 * base;
    }

    @Override
    public void displayColor() {
        System.out.println("Shape: Triangle");
        super.displayColor();
    }
}


