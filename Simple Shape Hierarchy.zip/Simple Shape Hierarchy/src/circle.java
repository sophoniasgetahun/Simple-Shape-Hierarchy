class Circle extends Shape {
    final double radius;

    public Circle(String color, double radius) {
        super(color);
        this.radius = radius;
    }

    public double calculateArea() {
        return Math.PI * radius * radius;
    }

    public double calculatePerimeter() {
        return 2 * Math.PI * radius;
    }

    @Override
    public void displayColor() {
        System.out.println("Shape: Circle");
        super.displayColor();
    }
}

