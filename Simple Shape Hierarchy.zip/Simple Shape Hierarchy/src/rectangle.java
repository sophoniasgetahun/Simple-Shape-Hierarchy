class Rectangle extends Shape {
    final double length;
    final double width;

    public Rectangle(String color, double length, double width) {
        super(color);
        this.length = length;
        this.width = width;
    }

    public double calculateArea() {
        return length * width;
    }

    public double calculatePerimeter() {
        return 2 * (length + width);
    }

    @Override
    public void displayColor() {
        System.out.println("Shape: Rectangle");
        super.displayColor();
    }
}

